<?php
$usuario="root";
$password="";
$host="";
$db="db_empl_b";

try {
    // $conn = new PDO('mysql:host=mysql-testingmultiverse.alwaysdata.net;dbname=testingmultiverse_symfo1', $usuario, $password);

    $conn = new PDO('mysql:host='.$host.';dbname='.$db, $usuario, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch(PDOException $e) {
    echo "ERROR: <br>" . $e->getMessage()."<br>".getTraceAsString();
}

 ?>
